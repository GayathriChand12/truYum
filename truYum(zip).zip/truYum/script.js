function validate()
{if(document.getElementById())
{ var x = document.forms["myform"]["title"].value;
var y== document.forms["myform"]["price"].value;
  if (x == "" || x == null) {
    alert("Title must be filled out");
   
  }
 else if(y == "" || y==null)
 {   alert("Price Value must be filled out");
   
 }
else
{ alert(Menu Item Updated);
}

}