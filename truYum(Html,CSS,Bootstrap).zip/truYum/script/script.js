
function validate(){
var x = document.forms["myform"]["fname"].value;
var y = document.forms["myform"]["price"].value;
  if (x == "" || x == null) {
    alert("Title must be filled out");
return false;  
   }
else  if (y == "" || y == null) {
    alert("Price must be filled out");
return false;  
   }

}